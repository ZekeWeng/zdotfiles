# Hexagonal Architecture

- Maintain hex (ports & adapters) architecture throughout the codebase
- Core domain logic must have zero external dependencies — no shell, OS, or editor coupling
- Define explicit ports (interfaces) at boundaries between core and the outside world
- Adapters wrap external concerns (shell, filesystem, editor plugins) and conform to ports
- Never leak adapter implementation details into core modules
- When adding new functionality, identify whether it belongs in core, a port, or an adapter
