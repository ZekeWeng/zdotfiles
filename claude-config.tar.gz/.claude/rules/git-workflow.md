# Git & Graphite Workflow

- Use **Graphite** (`gt`) for all branch and PR operations — not raw `git push` or `gh pr create`
- Stack PRs with `gt create` — each PR in a stack should be a single logical change
- Use `gt submit` to push stacks, not `git push`

# Commit Message Format

Use conventional commit prefixes. Format: `<type>: <short description>`

| Type       | Use when                                                  |
|------------|-----------------------------------------------------------|
| `feat`     | New feature                                               |
| `fix`      | Bug fix                                                   |
| `docs`     | Documentation only                                        |
| `style`    | Formatting, missing semi-colons, etc (no code change)     |
| `refactor` | Code change that neither fixes a bug nor adds a feature   |
| `perf`     | Performance improvement                                   |
| `test`     | Adding or updating tests                                  |
| `build`    | Build system or external dependencies                     |
| `ci`       | CI configuration files and scripts                        |
| `chore`    | Other changes that don't modify src or test files         |
| `revert`   | Revert a previous commit                                  |

- Keep the subject line under 50 characters — must not bleed into comments in `git log --oneline`
- Commits must be small, modular, and manageable — one concern per commit
- Write commit messages that explain *why*, not *what*
- Before committing, verify changes are scoped tightly — split unrelated changes into separate commits
- Never bundle formatting, refactoring, and feature work in the same commit

# Branch Naming

Format: `<type>/<folder>/<short-description>`

- Start with a conventional commit type from the table above
- Follow with the high-level folder being changed (e.g. `nvim`, `zsh`, `tmux`)
- End with a specific feature or fix, using `-` as word separators
- Keep branch names short — max ~40 characters total

Examples:
- `feat/nvim/add-lsp-keybinds`
- `fix/zsh/path-export-order`
- `refactor/tmux/split-config`
- `chore/stow/ignore-patterns`
