#!/bin/bash
# Stop hook: Quick sanity check before Claude finishes responding
# Exit 0 = allow stop, Exit 2 = force Claude to continue

# Check for uncommitted changes that might indicate unfinished work
UNSTAGED=$(git diff --name-only 2>/dev/null | wc -l | tr -d ' ')
STAGED=$(git diff --cached --name-only 2>/dev/null | wc -l | tr -d ' ')

if [ "$UNSTAGED" -gt 0 ] && [ "$STAGED" -gt 0 ]; then
  echo "{\"systemMessage\": \"Note: There are $UNSTAGED unstaged and $STAGED staged files. Consider whether all changes are committed.\"}"
fi

exit 0
