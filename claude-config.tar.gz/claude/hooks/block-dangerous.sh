#!/bin/bash
# PreToolUse hook: Block dangerous Bash commands
# Exit 0 = allow, Exit 2 = block (stderr shown to Claude)

INPUT=$(cat)
COMMAND=$(echo "$INPUT" | jq -r '.tool_input.command // empty')

# Block destructive commands
if echo "$COMMAND" | grep -qE '(rm -rf /|rm -rf \.|drop database|DROP TABLE|format |mkfs\.|:(){|fork bomb)'; then
  echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"Blocked: destructive command detected"}}'
  exit 0
fi

# Block pushing secrets
if echo "$COMMAND" | grep -qE '(\.env|credentials|secrets|\.pem|\.key)\b' | grep -qE 'git (add|commit)'; then
  echo '{"hookSpecificOutput":{"hookEventName":"PreToolUse","permissionDecision":"deny","permissionDecisionReason":"Blocked: potential secret file in git operation"}}'
  exit 0
fi

exit 0
