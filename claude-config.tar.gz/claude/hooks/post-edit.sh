#!/bin/bash
# PostToolUse hook: Run after file edits
# Runs linters/formatters if available. Non-blocking (exit 0 always).

INPUT=$(cat)
FILE_PATH=$(echo "$INPUT" | jq -r '.tool_input.file_path // empty')

if [ -z "$FILE_PATH" ]; then
  exit 0
fi

EXTENSION="${FILE_PATH##*.}"

# Run appropriate linter based on file type
case "$EXTENSION" in
  js|jsx|ts|tsx)
    if command -v npx &>/dev/null && [ -f "$CLAUDE_PROJECT_DIR/node_modules/.bin/eslint" ]; then
      RESULT=$(npx eslint "$FILE_PATH" 2>&1) || true
      if [ -n "$RESULT" ]; then
        echo "{\"systemMessage\": \"ESLint output for $FILE_PATH:\n$RESULT\"}"
      fi
    fi
    ;;
  py)
    if command -v ruff &>/dev/null; then
      RESULT=$(ruff check "$FILE_PATH" 2>&1) || true
      if [ -n "$RESULT" ]; then
        echo "{\"systemMessage\": \"Ruff output for $FILE_PATH:\n$RESULT\"}"
      fi
    fi
    ;;
  rs)
    if command -v cargo &>/dev/null; then
      RESULT=$(cargo check 2>&1) || true
      if [ -n "$RESULT" ]; then
        echo "{\"systemMessage\": \"Cargo check output:\n$RESULT\"}"
      fi
    fi
    ;;
esac

exit 0
