---
paths:
  - "**/*test*"
  - "**/*spec*"
  - "**/__tests__/**"
---

# Testing Rules

- Each test should verify one behavior with a descriptive name
- Tests must be independent — no shared mutable state between tests
- Use arrange/act/assert structure
- Prefer realistic test data over trivial values
- Always test error paths, not just happy paths
- Mock external dependencies (network, filesystem, databases) — never hit real services in tests
