---
paths:
  - "src/api/**"
  - "src/auth/**"
  - "**/*auth*"
  - "**/*login*"
  - "**/*password*"
---

# Security Rules

- Parameterize all database queries — never interpolate user input into SQL
- Sanitize and escape all user input before rendering in HTML
- Use constant-time comparison for secrets and tokens
- Never log sensitive data (passwords, tokens, PII)
- Set appropriate CORS, CSP, and security headers
- Validate and sanitize file paths to prevent directory traversal
