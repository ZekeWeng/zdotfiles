# General Coding Standards

- Write clear, self-documenting code — use descriptive names over comments
- Keep functions small and focused on a single responsibility
- Handle errors explicitly — never swallow exceptions silently
- Validate input at system boundaries (user input, API responses, file I/O)
- Never commit secrets, credentials, or API keys
- Prefer editing existing files over creating new ones
